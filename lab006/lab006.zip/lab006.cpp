// Lab 006 
// Name :
// Student ID :

#include "lab006.h"

template <class T>
void  MinHeap<T>::Pop()
{	// Pop the minimum element

	if(heapSize == 0)
		return;




}

template <class T>
void  MinHeap<T>::PreOrder(const int idx)
{
	if(idx > heapSize)
		return;






}


// DO NOT REMOVE THE FOLLOWING LINE
template class MinHeap<int> ;
