// Lab 001

#include <iostream>
