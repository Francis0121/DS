// LAB 010
// Name :
// Student ID :

#include "lab010.h"

template <class T>
void  HeapSort<T>::Adjust(const int root, int n)
{	// adjust binary tree with root "root" to satisfy heap property.
	// The left and right subtrees of "root" already satisfy the heap
	// property. No node index is > n.

	T e = heapArr[root];





}

template <class T>
void  HeapSort<T>::Heapify()
{	// reorder heapArr[1:n] into a heap




}


// DO NOT REMOVE THE FOLLOWING.
template class HeapSort<int>;

