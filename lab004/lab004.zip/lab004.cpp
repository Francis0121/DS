// Lab 004 
// Name :
// Student ID :

#include "lab004.h"

template <class T> 
Queue<T>::Queue(int queueCapacity) : capacity(queueCapacity)
{



}


// IMPLEMENT THE FUNCTIONS HERE





// Do Not Remove the followings
// This is for template instantiation
template class Queue<char>;


