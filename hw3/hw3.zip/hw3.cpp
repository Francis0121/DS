// HW 3
// Name :
// Student ID :

#include "hw3.h"


template <class T>
void  QuickSort<T>::Swap(int i, int j)
{


}


template <class T>
void  QuickSort<T>::QSort(int s, int e)
{	
	// sort arr[s:e] into nonincreasing order
	cout << "Sort in [" << s << "," << e << "]" << endl;
	Show(s, e);

	if(s >= e)
		return;

	// Implement at the following....








}


// DO NOT REMOVE THE FOLLOWING LINE
template class QuickSort<int>;


