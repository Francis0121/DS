// Lab 007 
// Name :
// Student ID :

#include "lab007.h"


template <class T>
void  MaxLoserTree<T>::BuildLoserTree(const T *externalnode, int n)
{   // initialize the array by using the input
	// Then, compute the internal nodes

    numofelements = n;


}


// DO NOT REMOVE THE FOLLOWING
template class MaxLoserTree<int>;


