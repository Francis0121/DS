// Lab 005
// Name :
// Student ID :

#include "lab005.h"

template <class T>
void CircularList<T>::InsertFront(const T & e)
{// Insert the element e at the front position


}


template <class T>
bool CircularList<T>::Delete(const T & e)
{
	// delete an element from the position theIndex






	return false;
}



template <class T>
int  CircularList<T>::Size() const 
{
	int cnt = 0;






	return cnt;
}




// DO NOT REMOVE THE FOLLOWINGS. 
template class CircularList<int>;


